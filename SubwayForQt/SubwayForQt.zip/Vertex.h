#pragma once
#include"define.h"
class Vertex
{
public:
	int Vid;
	set<string> pathName;
	Vertex(string pathName, int id);
private:

};


