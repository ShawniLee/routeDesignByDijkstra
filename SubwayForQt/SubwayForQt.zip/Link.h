#pragma once
#include"define.h"
class Link
{
public:
	int Lid;
	set<string> pathName;
	float distance;
	Link(string pathName, float distance);
private:

};

